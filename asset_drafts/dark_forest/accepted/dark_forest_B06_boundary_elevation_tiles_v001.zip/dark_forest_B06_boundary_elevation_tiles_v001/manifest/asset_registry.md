# Dark Forest Asset Registry Snapshot

Batch: `B06 — boundary_elevation_tiles`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `boundary_dense_forest_wall_01` | плотная лесная стена | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `boundary_dark_tree_wall_01` | тёмная чаща | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `boundary_ruin_barrier_01` | руинный барьер | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `boundary_swamp_barrier_01` | болотная преграда | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `boundary_cliff_wall_01` | край обрыва | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `elevation_lowland_shadow_edge_01` | тёмный край низины | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `elevation_raised_berm_edge_01` | край насыпи | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `elevation_hill_grass_edge_01` | травяной склон | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `elevation_stone_stairs_01` | каменная лестница | 16x16 | boundary/elevation | generated | accepted_by_workflow |
| `elevation_ancient_beacon_base_01` | основание древнего маяка | 16x16 | boundary/elevation | generated | accepted_by_workflow |
