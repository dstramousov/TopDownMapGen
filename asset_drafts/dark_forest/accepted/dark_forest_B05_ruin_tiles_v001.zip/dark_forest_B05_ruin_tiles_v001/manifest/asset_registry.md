# Dark Forest Asset Registry Snapshot

Batch: `B05 — ruin_tiles`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `ruin_floor_01` | каменный пол руин 1 | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_floor_cracked_01` | треснувший пол руин | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_wall_ns_01` | стена руин север-юг | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_wall_ew_01` | стена руин запад-восток | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_wall_corner_ne_01` | угол стены север-восток | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_wall_corner_nw_01` | угол стены север-запад | 16x16 | ruins | generated | accepted_by_workflow |
| `ruin_rubble_01` | руинный щебень | 16x16 | ruins | generated | accepted_by_workflow |
| `fallen_bricks_01` | упавшие кирпичи | 16x16 | ruins | generated | accepted_by_workflow |
| `broken_block_01` | сломанный каменный блок | 16x16 | ruins | generated | accepted_by_workflow |
| `mossy_stone_01` | камень со мхом | 16x16 | ruins | generated | accepted_by_workflow |
