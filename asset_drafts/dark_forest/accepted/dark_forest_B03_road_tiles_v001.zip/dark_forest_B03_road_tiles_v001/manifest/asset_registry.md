# Dark Forest Asset Registry Snapshot

Batch: `B03 — road_tiles`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `road_straight_ns_01` | старая дорога север-юг | 16x16 | road | generated | accepted_by_workflow |
| `road_straight_ew_01` | старая дорога запад-восток | 16x16 | road | generated | accepted_by_workflow |
| `road_turn_ne_01` | поворот дороги север-восток | 16x16 | road | generated | accepted_by_workflow |
| `road_turn_nw_01` | поворот дороги север-запад | 16x16 | road | generated | accepted_by_workflow |
| `road_turn_se_01` | поворот дороги юго-восток | 16x16 | road | generated | accepted_by_workflow |
| `road_turn_sw_01` | поворот дороги юго-запад | 16x16 | road | generated | accepted_by_workflow |
| `road_cross_01` | перекрёсток старой дороги | 16x16 | road | generated | accepted_by_workflow |
| `road_t_junction_n_01` | Т-развилка вверх | 16x16 | road | generated | accepted_by_workflow |
| `road_overgrown_01` | заросшая старая дорога | 16x16 | road | generated | accepted_by_workflow |
| `road_broken_patch_01` | разбитый участок дороги | 16x16 | road | generated | accepted_by_workflow |
