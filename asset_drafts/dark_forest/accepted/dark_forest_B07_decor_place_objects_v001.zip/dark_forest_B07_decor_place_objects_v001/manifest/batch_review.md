# B07 Review — decor_place_objects v001

По текущему workflow пакет временно считается accepted для общей проверки карты после 7 пакетов.
