# Dark Forest Asset Registry Snapshot

Batch: `B07 — decor_place_objects`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `decor_reeds_01` | камыш | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_dead_branch_01` | мёртвая ветка | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_small_stone_01` | маленький камень | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_broken_plank_01` | сломанная доска | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_campfire_ash_01` | пепелище | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_abandoned_crate_01` | брошенный ящик | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_firewood_stack_01` | стопка дров | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_hidden_cache_marker_01` | скрытый тайник | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_warning_bones_01` | предупреждающие кости | 16x16 | decor/place | generated | accepted_by_workflow |
| `decor_sandbag_remnant_01` | остатки мешков с песком | 16x16 | decor/place | generated | accepted_by_workflow |
