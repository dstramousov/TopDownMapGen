# Dark Forest Asset Registry Snapshot

Batch: `B08 — forest_large_clusters`  
Version: `v001`  
Status: `generated / pending_review`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `forest_cluster_32x32_01` | плотный кластер хвойного леса 32x32 | 32x32 | forest_overlay | generated | pending |
| `forest_cluster_32x32_02` | плотный кластер хвойного леса 32x32 вариант | 32x32 | forest_overlay | generated | pending |
| `forest_cluster_48x48_01` | крупный кластер хвойного леса 48x48 | 48x48 | forest_overlay | generated | pending |
| `forest_cluster_48x48_02` | крупный кластер хвойного леса 48x48 вариант | 48x48 | forest_overlay | generated | pending |
| `forest_wall_32x48_01` | тёмная лесная стена 32x48 | 32x48 | forest_overlay | generated | pending |
| `forest_wall_32x48_02` | тёмная лесная стена 32x48 вариант | 32x48 | forest_overlay | generated | pending |
| `forest_edge_cluster_n_32x32` | край леса север 32x32 | 32x32 | forest_overlay | generated | pending |
| `forest_edge_cluster_s_32x32` | край леса юг 32x32 | 32x32 | forest_overlay | generated | pending |
| `forest_edge_cluster_e_32x32` | край леса восток 32x32 | 32x32 | forest_overlay | generated | pending |
| `forest_edge_cluster_w_32x32` | край леса запад 32x32 | 32x32 | forest_overlay | generated | pending |
