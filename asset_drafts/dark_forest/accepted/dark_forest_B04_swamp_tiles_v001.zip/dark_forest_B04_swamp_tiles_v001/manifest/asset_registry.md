# Dark Forest Asset Registry Snapshot

Batch: `B04 — swamp_tiles`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `swamp_fill_01` | болотистая земля 1 | 16x16 | swamp | generated | accepted_by_workflow |
| `swamp_fill_02` | болотистая земля 2 | 16x16 | swamp | generated | accepted_by_workflow |
| `swamp_edge_mud_n_01` | грязный край болота север | 16x16 | swamp | generated | accepted_by_workflow |
| `swamp_edge_mud_s_01` | грязный край болота юг | 16x16 | swamp | generated | accepted_by_workflow |
| `swamp_edge_mud_e_01` | грязный край болота восток | 16x16 | swamp | generated | accepted_by_workflow |
| `swamp_edge_mud_w_01` | грязный край болота запад | 16x16 | swamp | generated | accepted_by_workflow |
| `mud_patch_01` | пятно грязи | 16x16 | swamp | generated | accepted_by_workflow |
| `wet_grass_01` | мокрая трава | 16x16 | swamp | generated | accepted_by_workflow |
| `water_puddle_01` | лужа | 16x16 | swamp | generated | accepted_by_workflow |
| `black_mud_01` | чёрная болотная грязь | 16x16 | swamp | generated | accepted_by_workflow |
