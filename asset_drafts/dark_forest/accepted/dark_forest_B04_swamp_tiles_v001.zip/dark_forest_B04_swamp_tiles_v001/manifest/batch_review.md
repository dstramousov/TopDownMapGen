# B04 Review — swamp_tiles v001

По текущему workflow пакет временно считается accepted для общей проверки карты после 7 пакетов.
