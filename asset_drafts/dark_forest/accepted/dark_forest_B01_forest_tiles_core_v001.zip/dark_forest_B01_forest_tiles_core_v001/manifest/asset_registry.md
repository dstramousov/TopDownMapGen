# Dark Forest Asset Registry Snapshot

Batch: `B01 — forest_tiles_core`  
Version: `v001`  
Status: `generated / pending_review`

## Style target

`dark_forest_post_soviet_ruins` — плотный тёмный хвойный лес, приглушённая палитра, читаемые края лесной массы.

## Assets in this batch

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `forest_fill_01` | плотный лес 1 | 16x16 | forest | generated | pending |
| `forest_fill_02` | плотный лес 2 | 16x16 | forest | generated | pending |
| `forest_edge_n` | край леса север | 16x16 | forest | generated | pending |
| `forest_edge_s` | край леса юг | 16x16 | forest | generated | pending |
| `forest_edge_e` | край леса восток | 16x16 | forest | generated | pending |
| `forest_edge_w` | край леса запад | 16x16 | forest | generated | pending |
| `forest_corner_ne` | угол леса север-восток | 16x16 | forest | generated | pending |
| `forest_corner_nw` | угол леса север-запад | 16x16 | forest | generated | pending |
| `forest_corner_se` | угол леса юго-восток | 16x16 | forest | generated | pending |
| `forest_corner_sw` | угол леса юго-запад | 16x16 | forest | generated | pending |
