# B01 Review — forest_tiles_core v001

Напиши после просмотра:

```text
accepted:
- forest_fill_01
- ...

needs_fix:
- forest_edge_n — причина

rejected:
- forest_corner_sw — причина
```

## Что проверять

- похоже ли на референсную карту;
- выглядит ли как плотный тёмный хвойный лес;
- читаются ли edge/corner тайлы;
- нет ли ощущения каши из пикселей;
- годится ли как реальный production asset.
