# Dark Forest Asset Registry Snapshot

Batch: `B02 — ground_grass_tiles`  
Version: `v001`  
Status: `generated / accepted_by_workflow`

| asset_id | Русское название | Размер | Категория | Status | Review |
|---|---|---:|---|---|---|
| `grass_base_01` | базовая трава 1 | 16x16 | ground | generated | accepted_by_workflow |
| `grass_base_02` | базовая трава 2 | 16x16 | ground | generated | accepted_by_workflow |
| `grass_base_03` | базовая трава 3 | 16x16 | ground | generated | accepted_by_workflow |
| `grass_patches_01` | трава с проплешинами 1 | 16x16 | ground | generated | accepted_by_workflow |
| `grass_patches_02` | трава с проплешинами 2 | 16x16 | ground | generated | accepted_by_workflow |
| `dirt_01` | сухая земля 1 | 16x16 | ground | generated | accepted_by_workflow |
| `dirt_02` | сухая земля 2 | 16x16 | ground | generated | accepted_by_workflow |
| `mud_01` | влажная земля / грязь | 16x16 | ground | generated | accepted_by_workflow |
| `rocky_ground_01` | каменистая земля 1 | 16x16 | ground | generated | accepted_by_workflow |
| `rocky_ground_02` | каменистая земля 2 | 16x16 | ground | generated | accepted_by_workflow |
