# B02 Review — ground_grass_tiles v001

По текущему workflow пакет временно считается accepted для общей проверки карты после 7 пакетов.
